var context = [];
document.getElementById("user-input").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        sendMessage();
    }
});

// Send message function with loading animation
async function sendMessage() {
    var prompt = '';
    context.forEach(element => {
        prompt = JSON.stringify(element);
    });
    var payload = {};
    const inputField = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');
    const message = prompt + ' ' + inputField.value.trim();
    payload.userMessage = message;

    if (message) {
        // Add user message
        const userMessage = document.createElement('div');
        userMessage.textContent = inputField.value.trim();
        userMessage.style.background = '#212623';
        userMessage.style.color = 'white';
        userMessage.style.padding = '12px 18px';
        userMessage.style.margin = '8px 0';
        userMessage.style.borderRadius = '15px';
        userMessage.style.alignSelf = 'flex-end';
        userMessage.style.maxWidth = '80%';
        userMessage.style.boxShadow = '0 2px 5px rgba(0,0,0,0.1)';
        chatBox.appendChild(userMessage);

        // Add loading animation
        const loader = document.createElement('div');
        loader.className = 'loader';
        chatBox.appendChild(loader);
        chatBox.scrollTop = chatBox.scrollHeight;
        inputField.value = '';

        try {
            const response = await fetch('/generate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: message })
            });

            const data = await response.json();
            console.log(data.reply);
            // Remove loader
            chatBox.removeChild(loader);
            payload.aiResponse = data.reply;
            context.push(payload);

            // Format AI response
            let formattedText = data.reply
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')  // Bold
                .replace(/\n/g, '<br>')  // New lines
                .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');  // Code blocks

            // Add bot response
            const botMessage = document.createElement('div');
            botMessage.innerHTML = formattedText; // Use innerHTML to render formatting
            botMessage.style.background = '#2C2040';
            botMessage.style.color = '#fff';
            botMessage.style.padding = '12px 18px';
            botMessage.style.margin = '8px 0';
            botMessage.style.borderRadius = '15px';
            botMessage.style.alignSelf = 'flex-start';
            botMessage.style.maxWidth = '80%';
            botMessage.style.boxShadow = '0 2px 5px rgba(0,0,0,0.1)';
            chatBox.appendChild(botMessage);
            chatBox.scrollTop = chatBox.scrollHeight;
        } catch (error) {
            console.error('Error fetching response:', error);
            chatBox.removeChild(loader);
            const errorMessage = document.createElement('div');
            errorMessage.textContent = 'Oops! Something went wrong. Try again!';
            errorMessage.style.background = '#ff4562';
            errorMessage.style.color = 'white';
            errorMessage.style.padding = '12px 18px';
            errorMessage.style.margin = '8px 0';
            errorMessage.style.borderRadius = '15px';
            errorMessage.style.alignSelf = 'flex-start';
            errorMessage.style.maxWidth = '80%';
            chatBox.appendChild(errorMessage);
            chatBox.scrollTop = chatBox.scrollHeight;
        }
    }
}


// Delete button functionality
document.getElementById('delete-btn').addEventListener('click', function() {
    const chatBox = document.getElementById('chat-box');
    chatBox.innerHTML = '';
    const welcomeMessage = document.createElement('div');
    welcomeMessage.textContent = 'Hey there! Ready to explore some hidden gems? Ask me anything!';
    welcomeMessage.style.textAlign = 'center';
    welcomeMessage.style.color = '#fff';
    welcomeMessage.style.padding = '15px';
    welcomeMessage.style.fontSize = '18px';
    welcomeMessage.style.fontStyle = 'italic';
    welcomeMessage.style.background = 'linear-gradient(45deg, #007bff, #00d4ff)';
    welcomeMessage.style.borderRadius = '12px';
    welcomeMessage.style.marginBottom = '15px';
    welcomeMessage.style.boxShadow = '0 3px 10px rgba(0, 0, 0, 0.2)';
    welcomeMessage.style.maxWidth = '85%';
    welcomeMessage.style.alignSelf = 'center';
    chatBox.appendChild(welcomeMessage);
});

// Attach files button functionality
document.getElementById('attach-btn').addEventListener('click', function() {
    document.getElementById('file-input').click();
});

document.getElementById('file-input').addEventListener('change', function() {
    const chatBox = document.getElementById('chat-box');
    const files = this.files;
    if (files.length > 0) {
        const fileMessage = document.createElement('div');
        let fileList = 'Attached files:\n';
        for (let i = 0; i < files.length; i++) {
            fileList += `- ${files[i].name} (${(files[i].size / 1024).toFixed(2)} KB)\n`;
        }
        fileMessage.textContent = fileList;
        fileMessage.style.background = 'linear-gradient(45deg, #17a2b8, #20c997)';
        fileMessage.style.color = 'white';
        fileMessage.style.padding = '12px 18px';
        fileMessage.style.margin = '8px 0';
        fileMessage.style.borderRadius = '15px';
        fileMessage.style.alignSelf = 'flex-end';
        fileMessage.style.maxWidth = '80%';
        fileMessage.style.boxShadow = '0 2px 5px rgba(0,0,0,0.1)';
        fileMessage.style.whiteSpace = 'pre-line'; // Preserve line breaks
        chatBox.appendChild(fileMessage);
        chatBox.scrollTop = chatBox.scrollHeight;
        this.value = ''; // Reset file input
    }
});

// Theme button functionality
let isDarkTheme = false;
document.getElementById('theme-btn').addEventListener('click', function() {
    const chatContainer = document.querySelector('.chat-container');
    const chatBox = document.getElementById('chat-box');
    const chatInput = document.querySelector('.chat-input');
    const themeIcon = this.querySelector('img');

    if (!isDarkTheme) {
        chatContainer.style.background = 'linear-gradient(135deg, rgba(30, 30, 30, 0.95), rgba(50, 50, 50, 0.9))';
        chatBox.style.background = 'rgba(40, 40, 40, 0.9)';
        chatBox.style.color = '#fff';
        chatInput.style.background = 'linear-gradient(to top, rgba(50, 50, 50, 0.95), rgba(70, 70, 70, 0.95))';
        themeIcon.src = 'https://img.icons8.com/ios-filled/24/ffffff/moon-symbol.png';
        isDarkTheme = true;
    } else {
        chatContainer.style.background = 'linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(240, 244, 248, 0.9))';
        chatBox.style.background = 'rgba(255, 255, 255, 0.9)';
        chatBox.style.color = 'inherit';
        chatInput.style.background = 'linear-gradient(to top, rgba(248, 249, 250, 0.95), rgba(255, 255, 255, 0.95))';
        themeIcon.src = 'https://img.icons8.com/ios-filled/24/ffffff/sun.png';
        isDarkTheme = false;
    }
});

// Voice button functionality
document.getElementById('voice-btn').addEventListener('click', function() {
    const inputField = document.getElementById('user-input');
    const voiceBtn = this;

    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        voiceBtn.style.background = 'linear-gradient(45deg, #e84393, #ff7675)';
        inputField.placeholder = 'Listening...';

        recognition.onstart = function() {
            console.log('Voice recognition started.');
        };

        recognition.onresult = function(event) {
            const speechResult = event.results[0][0].transcript;
            inputField.value = speechResult;
            sendMessage();
        };

        recognition.onerror = function(event) {
            console.error('Speech recognition error:', event.error);
            let errorMessage = '';
            switch (event.error) {
                case 'no-speech':
                    errorMessage = 'No speech detected. Please speak clearly!';
                    break;
                case 'audio-capture':
                    errorMessage = 'Microphone issue. Check your device!';
                    break;
                case 'not-allowed':
                    errorMessage = 'Microphone access denied. Allow permissions!';
                    break;
                case 'network':
                    errorMessage = 'Network error. Check your connection!';
                    break;
                default:
                    errorMessage = 'Speech recognition failed. Try again!';
            }
            inputField.value = errorMessage;
        };

        recognition.onend = function() {
            console.log('Voice recognition ended.');
            voiceBtn.style.background = 'linear-gradient(45deg, #6f42c1, #9b59b6)';
            inputField.placeholder = 'Type your message here...';
        };

        try {
            recognition.start();
        } catch (error) {
            console.error('Error starting recognition:', error);
            inputField.value = 'Failed to start voice recognition. Try again!';
            voiceBtn.style.background = 'linear-gradient(45deg, #6f42c1, #9b59b6)';
        }
    } else {
        inputField.value = 'Speech recognition not supported in this browser.';
    }
});